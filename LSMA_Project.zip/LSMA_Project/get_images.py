
# coding: utf-8

# Need to do the following command first:
# pip install -r requirements.txt

import pandas as pd
import numpy as np
import requests
from subprocess import call
import os.path

with open("imagenet_URLs.txt") as fp:
	for line in fp:
	    request = requests.get(url)
	    if request.status_code == 200:
	        count+=1
	        print count
	        print('Web site exists... Downloading Image')
	        call('wget '+ url,shell=True)
	        if count == 10000:
	            print("10000 Images Collected!")
	            break